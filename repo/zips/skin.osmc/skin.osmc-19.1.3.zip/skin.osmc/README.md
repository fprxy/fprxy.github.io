# skin.osmc

The default skin for OSMC.

For further information, check out the wiki here: https://osmc.tv/wiki/general/the-osmc-skin/

## This skin is shipped with official releases of OSMC (https://osmc.tv/download/).

Install from GitHub on other platforms - check for the newest release here: https://github.com/osmc/skin.osmc/releases

Original skin: Andy Morton (https://github.com/BobCratchett)

Original design: Simon Brunton (https://simonbrunton.com/)

Skinner: Julian Michel (https://github.com/Ch1llb0/skin.osmc)
